/*
** This script validates the content for a form based on specific rules
** for each item in the form
*/
window.onload = init;
function init() {
// when page loads attach event to validate form
var formsubmit = document.getElementById("submit");
if (formsubmit) {
formsubmit.onclick = checkForm;
}
}
function checkForm() {
// test the fields in the form
// FIRSTNAME: Required, at least two letters long
var firstname = document.getElementById('firstname').value;
var firstname_msg = document.getElementById('firstname_msg');
var valid = true;
if (firstname.length < 3) {
firstname_msg.innerHTML = "Name should be at least 3 letters in length";
firstname_msg.className = 'error';
valid = false;
} else {
firstname_msg.innerHTML = "";
firstname_msg.className = '';
}

// PHONENUMBER: Required, at least two numbers long
var phone = document.getElementById('phone').value;
var phone_msg = document.getElementById('phone_msg');
if (phone.length < 7) {
phone_msg.innerHTML = "Phone number should be at least 7 numbers in length";
phone_msg.className = 'error';
valid = false;
} else {
phone_msg.innerHTML = "";
phone_msg.className = '';
}
// EMAIL: Not required, but if not blank, then must be valid email address
var email = document.getElementById('email').value;
var email_msg = document.getElementById('email_msg');

// regular expression for validatin
var emailRegExp = /^(\w+@[a-z\d]+?([a-z-\d_\.]*?)\.[a-z]{2,6})$/i;
if (email.length < 7){
email_msg.innerHTML = "Must be a valid email address";
email_msg.className = 'error';
valid = false;
} else {
email_msg.innerHTML = "";
email_msg.className = '';
}


// TANDCAGREE: must be checked
var tandcagree = document.getElementById('tandcagree').checked;
var tandcagree_msg = document.getElementById('tandcagree_msg');
if (!tandcagree) {
tandcagree_msg.innerHTML = "You must check the box.";
tandcagree_msg.className = 'error';
valid = false;
} else {
tandcagree_msg.innerHTML = "";
tandcagree_msg.className = '';
}
return valid;
}
